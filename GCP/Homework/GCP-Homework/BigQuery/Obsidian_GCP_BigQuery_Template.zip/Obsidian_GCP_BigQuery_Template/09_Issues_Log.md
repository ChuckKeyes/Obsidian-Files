---
title: 09_Issues_Log
---

# Issues / Decisions Log

- YYYY-MM-DD — Decision: <!-- what/why -->
- YYYY-MM-DD — Error: <!-- message --> | Fix: <!-- notes -->
