# Obsidian GCP BigQuery Template

Drop this folder into your Obsidian vault. Start with `00_Index.md`.
