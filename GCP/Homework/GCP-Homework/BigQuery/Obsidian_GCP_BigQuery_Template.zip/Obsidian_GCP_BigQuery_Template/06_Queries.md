---
title: 06_Queries
---

# Saved Queries

- **Sanity**: SELECT 1;
- **Row counts**: SELECT COUNT(*) FROM `project.dataset.table`;
- **Partition checks**: SHOW OPTIONS FOR TABLE `...`;

## Terraform-driver queries
Document any `google_bigquery_job` or DDL/DML from code.
